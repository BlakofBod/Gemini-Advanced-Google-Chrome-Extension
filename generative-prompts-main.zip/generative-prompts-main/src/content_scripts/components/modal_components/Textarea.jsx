import TextareaAutoSize from 'react-textarea-autosize';
const Textarea = (props) => {
	return <TextareaAutoSize {...props} />;
};

export default Textarea;
